package figuren;

public interface ICSVString {
	public String toCSVString();
}
