/**
 * @author rollins
 */
package figuren;

public interface INamed {
	public String name() ;
}
